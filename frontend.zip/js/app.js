const API_BASE = 'http://localhost:3000/api/destinations';

const cardGrid = document.getElementById('cardGrid');
const statusMsg = document.getElementById('statusMsg');
const filterPills = document.querySelectorAll('.filter-pill');

const overlay = document.getElementById('addFormOverlay');
const openBtn = document.getElementById('openAddForm');
const closeBtn = document.getElementById('closeAddForm');
const addForm = document.getElementById('addForm');
const formMsg = document.getElementById('formMsg');

let currentCategory = '';

const CATEGORY_LABEL = {
  natural: 'ธรรมชาติ',
  religion: 'ศาสนา',
  cultural: 'วัฒนธรรม',
  history: 'ประวัติศาสตร์',
};

// ชื่อไฟล์รูปภาพตั้งตาม titleeng (เว้นวรรค -> underscore) เช่น "Sanam Chan" -> Sanam_Chan.jpg
function imageFileFor(titleeng) {
  return `images/${String(titleeng).trim().replace(/\s+/g, '_')}.jpg`;
}

function renderStars(rating) {
  const n = Math.max(0, Math.min(5, Number(rating) || 0));
  return '★'.repeat(n) + '☆'.repeat(5 - n);
}

function createCard(dest) {
  const card = document.createElement('article');
  card.className = 'dest-card';

  const catClass = `cat-${dest.category}`;
  const catLabel = CATEGORY_LABEL[dest.category] || dest.category;
  const imgSrc = imageFileFor(dest.titleeng);

  card.innerHTML = `
    <div class="card-image-wrap">
      <img src="${imgSrc}" alt="${dest.titleth}"
           onerror="this.onerror=null; this.src='images/placeholder.svg';">
      <span class="cat-badge ${catClass}">${catLabel}</span>
      <span class="rating-badge">${renderStars(dest.rating)}</span>
    </div>
    <div class="card-body">
      <h3>${dest.titleth}</h3>
      <p class="card-titleeng">${dest.titleeng}</p>
      <p class="card-location">📍 ${dest.location}</p>
      <p class="card-desc">${dest.description || ''}</p>
    </div>
  `;
  return card;
}

async function loadDestinations(category = '') {
  currentCategory = category;
  statusMsg.textContent = 'กำลังโหลดข้อมูล...';
  cardGrid.innerHTML = '';

  try {
    const url = category ? `${API_BASE}?category=${encodeURIComponent(category)}` : API_BASE;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`เซิร์ฟเวอร์ตอบกลับผิดพลาด (${res.status})`);

    const data = await res.json();

    if (!Array.isArray(data) || data.length === 0) {
      cardGrid.innerHTML = '<p class="empty-state">ยังไม่มีข้อมูลสถานที่ท่องเที่ยวในหมวดนี้</p>';
      statusMsg.textContent = '';
      return;
    }

    data.forEach((dest) => cardGrid.appendChild(createCard(dest)));
    statusMsg.textContent = `พบสถานที่ท่องเที่ยวทั้งหมด ${data.length} แห่ง`;
  } catch (err) {
    cardGrid.innerHTML = `<p class="error-state">เชื่อมต่อ API ไม่สำเร็จ: ${err.message}<br>ตรวจสอบว่ารัน "npm start" ในโฟลเดอร์ backend ไว้อยู่หรือไม่</p>`;
    statusMsg.textContent = '';
  }
}

// ---------- ข้อ 4.2: กรองตามประเภท ----------
filterPills.forEach((pill) => {
  pill.addEventListener('click', () => {
    filterPills.forEach((p) => p.classList.remove('is-active'));
    pill.classList.add('is-active');
    loadDestinations(pill.dataset.category);
  });
});

// ---------- ข้อ 4.3: ฟอร์มเพิ่มสถานที่ท่องเที่ยว ----------
openBtn.addEventListener('click', () => {
  overlay.classList.remove('hidden');
  formMsg.textContent = '';
  formMsg.classList.remove('success');
});

closeBtn.addEventListener('click', () => overlay.classList.add('hidden'));
overlay.addEventListener('click', (e) => {
  if (e.target === overlay) overlay.classList.add('hidden');
});

addForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const payload = {
    titleeng: document.getElementById('titleeng').value.trim(),
    titleth: document.getElementById('titleth').value.trim(),
    category: document.getElementById('category').value,
    location: document.getElementById('location').value.trim(),
    description: document.getElementById('description').value.trim(),
    rating: Number(document.getElementById('rating').value),
  };

  formMsg.classList.remove('success');
  formMsg.textContent = 'กำลังบันทึก...';

  try {
    const res = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const result = await res.json();

    if (!res.ok) throw new Error(result.message || 'บันทึกไม่สำเร็จ');

    formMsg.classList.add('success');
    formMsg.textContent = `เพิ่ม "${payload.titleth}" สำเร็จ`;
    addForm.reset();
    loadDestinations(currentCategory); // โหลดรายการใหม่ให้เห็นข้อมูลที่เพิ่ง POST เข้าไป

    setTimeout(() => overlay.classList.add('hidden'), 1200);
  } catch (err) {
    formMsg.textContent = `เกิดข้อผิดพลาด: ${err.message}`;
  }
});

// โหลดข้อมูลทั้งหมดตอนเปิดหน้าเว็บครั้งแรก (ข้อ 4.1)
loadDestinations();
